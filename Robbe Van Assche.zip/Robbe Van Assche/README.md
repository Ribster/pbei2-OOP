# pbei2-OOP
OOP project in C++ for the course Object Orientated Programming
